import React, { ChangeEvent, useState } from 'react';
import { AsyncSelect, InlineField, Input, Select, Stack } from '@grafana/ui';
import { QueryEditorProps } from '@grafana/data';
import { DataSource } from '../datasource';
import { MyDataSourceOptions, AMSQuery } from '../types';

type Props = QueryEditorProps<DataSource, AMSQuery, MyDataSourceOptions>;

export function QueryEditor({ query, onChange, onRunQuery, datasource }: Props) {
  const { component, metric, hosts, aggregator, alias, transform, precision } = query;
  const [metricOptionsValue, setMetricOptionsValue] = useState<{ [key: string]: any[] }>({});

  const generateComponentOptions = async () => {
    const { component, allMetrics } = await datasource.generateOptions();
    setMetricOptionsValue(allMetrics);
    // onChange({ ...query, component: defaultComponent});
    return component;
  };

  const onComponentChange = (v: any) => {
    let metricOptions: Array<{ label: any; value: any; }> = [];
    metricOptionsValue[v.value ?? ''].map((item: any) => {
      metricOptions.push({ label: item.label, value: item.value });
    })
    // let m = metricOptions.find((item: any) => item.value === v.value);
    onChange({ ...query, component: v });
    if (query.metric !== undefined) {
      onChange({ ...query, metric: metricOptions[0] });

    }
    onRunQuery();
  };

  const onMetricChange = (v: any) => {
    onChange({ ...query, metric: v });
    onRunQuery();
  };

  const onHostsChange = (v: any) => {
    onChange({ ...query, hosts: v });
    onRunQuery();
  };

  const generateMetricOptions = async () => {
    let metricOptions: Array<{ label: any; value: any; }> = [];
    metricOptionsValue[component.value ?? ''].map((item: any) => {
      metricOptions.push({ label: item.label, value: item.value });
    })
    return metricOptions;
  };

  const generateHostsOptions = async () => {
    const { compToHostMap } = await datasource.generateHostsOptions();
    let metricOptions: Array<{ label: any; value: any; }> = [];
    compToHostMap[component.value ?? ''].map((item: any) => {
      metricOptions.push({ label: item, value: item });
    })
    return metricOptions;
  };

  const onAggregatorChange = (v: any) => {
    onChange({ ...query, aggregator: v });
  }

  const generateAggregatorOptions = () => {
    const options = [
      { label: 'none', value: 'none' },
      { label: 'avg', value: 'avg' },
      { label: 'sum', value: 'sum' },
      { label: 'min', value: 'min' },
      { label: 'max', value: 'max' },
    ];
    return options;
  };

  const onAliasChange = (event: ChangeEvent<HTMLInputElement>) => {
    onChange({ ...query, alias: event.target.value });
  }

  const onTransformChange = (v: any) => {
    onChange({ ...query, transform: v });
  }

  const generateTransformOptions = () => {
    const options = [
      { label: 'none', value: 'none' },
      { label: 'diff', value: 'diff' },
      { label: 'rate', value: 'rate' },
    ];
    return options;
  };

  const onPrecisionChange = (v: any) => {
    onChange({ ...query, precision: v });
  }

  const generatePrecisionOptions = () => {
    const options = [
      { label: 'default', value: 'default' },
      { label: 'seconds', value: 'seconds' },
      { label: 'minutes', value: 'minutes' },
      { label: 'hours', value: 'hours' },
      { label: 'days', value: 'days' },
    ];
    return options;
  };

  return (
    <>
      <Stack gap={0}>
        <InlineField label="Component">
          <AsyncSelect
            id="query-editor-component"
            defaultOptions
            onChange={onComponentChange}
            value={component}
            loadOptions={generateComponentOptions}
            width={25}
            placeholder="Component Name"
            showAllSelectedWhenOpen={true}
          // onBlur={generateMetricOptions}
          />
        </InlineField>
        <InlineField label="Metric">
          <AsyncSelect
            id="query-editor-metric"
            key={Math.random()}
            defaultOptions
            onChange={onMetricChange}
            value={metric}
            loadOptions={generateMetricOptions}
            width={25}
            placeholder="Metric Name"
          />
        </InlineField>
        <InlineField label="Hosts">
          <AsyncSelect
            id="query-editor-hosts"
            key={Math.random()}
            defaultOptions
            onChange={onHostsChange}
            value={hosts}
            loadOptions={generateHostsOptions}
            width={25}
            placeholder="Hosts Name"
          />
        </InlineField>
        <InlineField label="Aggregator">
          <Select
            id="query-editor-aggregator"
            onChange={onAggregatorChange}
            value={aggregator}
            options={generateAggregatorOptions()}
            width={25}
            placeholder="Choose Aggregator"
          />
        </InlineField>

      </Stack>
      <Stack>
        <InlineField label="Alias">
          <Input value={alias} placeholder="Series Alias" onChange={onAliasChange} />
        </InlineField>
        <InlineField label="Transform">
          <Select
            id="query-editor-aggregator"
            onChange={onTransformChange}
            value={transform}
            options={generateTransformOptions()}
            width={25}
            placeholder="Choose Transform"
          />
        </InlineField>
        <InlineField label="Precision">
          <Select
            id="query-editor-aggregator"
            onChange={onPrecisionChange}
            value={precision}
            options={generatePrecisionOptions()}
            width={25}
            placeholder="Choose Precision"
          />
        </InlineField>
      </Stack>
    </>
  );
}
